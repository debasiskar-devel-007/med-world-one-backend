export declare class FileUploadModule {
}
