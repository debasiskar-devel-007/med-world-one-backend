export declare class LoginModule {
}
